import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Linea, Reserva } from '../shared/cliente.model';
import { ClienteService } from '../shared/cliente.service';
import { StorageService } from '../shared/storage.service';

@Component({
  selector: 'app-detalle-linea',
  templateUrl: './detalle-linea.page.html',
  styleUrls: ['./detalle-linea.page.scss'],
})
export class DetalleLineaPage implements OnInit {

  linea:Linea;
  cliente: any;


    constructor(private router:Router, private route:ActivatedRoute, protected storage: StorageService) {

      this.route.params.subscribe((params) =>{
        this.storage.get('factura').then(factura=>{
          factura.Lineas.forEach((linea:Linea) => {
            if(linea.NumLinea == params['id'])
            {
              this.linea = linea;
            }
          });
        })
      })
  }

  ngOnInit() {

  }

}
