import { Component } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Cliente, Coches, Reserva } from '../shared/cliente.model';
import { ClienteService } from '../shared/cliente.service';
import { StorageService } from '../shared/storage.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  reservas: Reserva[] = [];
  reserva: Reserva;
  cliente: Cliente;
  cocheReservado: Coches;

  constructor(protected router: Router, protected clienteServicio: ClienteService, protected route: ActivatedRoute, public storage: StorageService) {
    storage.get('cliente').then(c => {
      if (c==null)
        this.router.navigate(['']);
      else
        this.cliente=c;


       this.route.queryParams.subscribe(params => {

        this.clienteServicio.dameReservas(this.cliente.DNI).subscribe
          (
            (rs: Reserva[]) => {

              this.reservas = rs;
              this.cliente.Reservas = this.reservas;
              rs.forEach(async r => {
                console.log("r : " + r.Id);

                if (r.Id == await this.storage.get('reservaId') as Number) {
                  this.reserva = r;
                }
              })
            }
          );
      })
    })
  }


  ngOnInit() {
    this.route.paramMap
      .subscribe((queryParams: ParamMap) => {
        console.log("iddd : " + queryParams.get('resId'));
        //this.memberId = queryParams.get('id');
      });
  }

  estadoCoche(num) {
    switch (num) {
      case 1:
        return "libre";
      case 2:
        return "alquilado";
    }
  }

  categoriaCoche(num) {
    switch (num) {
      case 1:
        return "económico";
      case 2:
        return "estándar";
      case 3:
        return "de lujo";
    }
  }

}
