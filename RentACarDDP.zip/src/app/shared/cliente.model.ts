export interface Cliente{
    DNI: string;
    Pass:string;
    Nombre?:string;
    Direccion?:string;
    Telefono?:string;
    Facturas?: Factura[];
    Reservas?: Reserva[];
}

export interface Factura{
    Id: number;
    Fecha: Date;
    EsPagada: Boolean;
    EsAnulada: Boolean;
    Lineas: Linea [];
    DameTotal: number;
}

export interface Linea {
    NumLinea: number;
    Precio: number;
}
export interface Reserva {
  Id:     number;
  Inicio: Date;
  Final:  Date;
  Coches: Coches;
}

export interface Coches {
  NumLicencia: number;
  Categoria:   number;
  Estado:      number;
}
