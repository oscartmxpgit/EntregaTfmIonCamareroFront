import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Factura, Linea } from '../shared/cliente.model';
import { ClienteService } from '../shared/cliente.service';
import { StorageService } from '../shared/storage.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  factura:Factura;

  constructor(private router:Router, private route:ActivatedRoute, public storage: StorageService) {
    this.route.queryParams.subscribe(params=>{

      storage.get('cliente').then(c=>{

        c.Facturas.forEach(f => {
          if(f.id==params['id'] as number){
            this.factura=f;
            this.storage.set('factura', f);
          }
        })
      })
    })
  }


  detalleLinea(numLinea: Number) {
    this.router.navigate(['detalle-linea/' + numLinea]);
    //this.storage.set('detalle-linea', linea.Id);
    //this.router.navigate(['detalle-linea'], { queryParams: { linea: linea } });

}



}
