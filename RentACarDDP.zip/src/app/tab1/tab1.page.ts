import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Cliente, Factura, Reserva } from '../shared/cliente.model';
import { ClienteService } from '../shared/cliente.service';
import { StorageService } from '../shared/storage.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  cliente: Cliente = null;
  reservas: Reserva[] = [];

  constructor(private clienteServicio: ClienteService, private storage: StorageService, private router: Router) {

    this.storage.get('cliente').then((cliente) =>{
      if(cliente != null)
      {
        this.cliente = cliente;
        this.clienteServicio.dameReservas(this.cliente.DNI).subscribe
        (
          (rs: Reserva[]) => {
            this.reservas = rs;
            this.cliente.Reservas=this.reservas;
            //console.log("Reservas : " + JSON.stringify(this.cliente.Reservas));
          }
        );

      }
    }).catch((error)=>{
        console.log(error);
      });

  }

  detalleFactura(factura: Factura) {
    this.router.navigate(['tab2'], {
      queryParams: {
        id: factura.Id
      }
    });
  }

  detalleReserva(reserva: Reserva) {
    this.storage.set('reservaId', reserva.Id);

  }
  ngOnInit() {


  }

}
